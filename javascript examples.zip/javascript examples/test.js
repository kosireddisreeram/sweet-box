function add(x,y) {
    
    return x+y;

}

add(1,2);
