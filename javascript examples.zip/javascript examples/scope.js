// 'use strict';
// function calcAge(birthYear) {
//     const age=2037-birthYear;
//     console.log(firstName); //it did not find the variable so it looked for the variable look up in the scope chain
//    function printAge(){
//        const output=`you are the ${age}, born in ${birthYear}`;
//        console.log(output);
//    }
//    printAge();

//     return age;
// }

// const firstName='jonas';// The global in scope
// calcAge(1991);
const myname='jonas';
if (myname==='jonas')

   {
    var job='teacher';
    var age=1991;
    console.log(job);
console.log(age);
}
console.log(job);


