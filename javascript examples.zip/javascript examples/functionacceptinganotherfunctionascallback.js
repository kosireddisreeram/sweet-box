const gret = gret(hey);
gret(helllo)(john);