console.log(me);
console.log(job);
console.log(birthYear);
 var me='jonas';
let job='teacher';
const birthYear=1991;
// 
// the best practice is to write the code with declaring the variables in it
// we know that the variable value will be changed after some time use let
// we know that the variable value will never be changed go with the const
// hoisting- accessing the variable before they are mentioned 
// this will work only with the var keyword apart from the let and const wont work they will return error or undefined
