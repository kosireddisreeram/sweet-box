console.log("hi");
const john = {
  name: "sreeram",
  age: "19",
  surname: "kosireddi",
  profile: "software",
  friends: [`all are my friends`],
};
console.log(john);
